public class Game {
    public static void main(String[] args) throws  InterruptedException {
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
    }
}


